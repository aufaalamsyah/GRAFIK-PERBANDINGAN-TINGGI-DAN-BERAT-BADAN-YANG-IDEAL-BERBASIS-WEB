let chartBMI;

function keSlide2() {
    slide1.classList.add("hidden");
    slide2.classList.remove("hidden");
}

function hitungBMI() {
    let bb = parseFloat(bbInput.value);
    let tb = parseFloat(tbInput.value) / 100;
    let bmi = (bb / (tb * tb)).toFixed(1);

    hasilBMI.innerHTML = "BMI: " + bmi;
    kategoriBMI.innerHTML = bmi < 18.5 ? "Kurus" : bmi <= 22.9 ? "Ideal" : "Berlebih";

    slide2.classList.add("hidden");
    slide3.classList.remove("hidden");
}

function hitungUlang() {
    slide3.classList.add("hidden");
    slide2.classList.remove("hidden");
}
